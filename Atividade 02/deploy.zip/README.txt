Execute o arquivo main.py e você terá algumas opções no terminal para interagir com as resoluções produzidas.

Qualquer coisa é só entrar em contato comigo pelo discord -> frbreno