# Lista 4 - Prática com JSON, YAML e Arquivos de Logs em APIs de Logging

## Discentes
1. Francisco Breno da Silveira (511429)
2. João Victor Amarante Diniz (510466)

## Observações
1. Foi utilizado o ChatGPT para gerar mais exemplos de dados para o arquivo `data.json`.